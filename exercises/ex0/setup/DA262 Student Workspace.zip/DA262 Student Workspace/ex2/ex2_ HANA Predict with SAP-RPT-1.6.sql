
-- Step 1;
SELECT * FROM REMOTE_SOURCES;


-- Step 2;
SELECT TRANSACTION_ID, ORIGIN, CLASS, AMOUNT, OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST, FRAUD
FROM DA262_SHARED.TRANSACTIONS_FRAUD ORDER BY TRANSACTION_ID;


-- Step 3;
-- selecting CONTEXT and TRANSACTIONS to PREDICT FRAUD;
DO BEGIN 
    /*** Select a stratified random sample for ~2039 rows, of which ~39 are fraudulent flagged transaction, as context to be forwarded to SAP-RPT-1.6 with the prediction call *******/
    CONTEXT = SELECT TRANSACTION_ID, ORIGIN, CLASS, AMOUNT, OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST, FRAUD 
    		  FROM DA262_SHARED.TRANSACTIONS_FRAUD TABLESAMPLE BERNOULLI (1.0) WHERE FRAUD = 0 AND TRANSACTION_ID < 200000  
    		  UNION 
    		  SELECT TRANSACTION_ID, ORIGIN, CLASS, AMOUNT, OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST, FRAUD 
    		  FROM DA262_SHARED.TRANSACTIONS_FRAUD TABLESAMPLE BERNOULLI (1.0) WHERE FRAUD = 1 AND TRANSACTION_ID < 200000 ;
    
    /*** Select rows where to predict Fraud, which we also prepare as a stratified sample of ~104rows, which 8 are fraudulent in the test data *******************/
    PREDICT = SELECT TRANSACTION_ID, ORIGIN, CLASS, AMOUNT, OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST 
    		  FROM DA262_SHARED.TRANSACTIONS_FRAUD TABLESAMPLE BERNOULLI (0.03) WHERE FRAUD = 0  AND TRANSACTION_ID > 200000 
    		  UNION 
              SELECT TRANSACTION_ID, ORIGIN, CLASS, AMOUNT, OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST 
    		  FROM DA262_SHARED.TRANSACTIONS_FRAUD TABLESAMPLE BERNOULLI (0.2) WHERE FRAUD = 1  AND TRANSACTION_ID > 200000;
 
    CREATE LOCAL TEMPORARY COLUMN TABLE "#CONTEXT" AS (SELECT * FROM :CONTEXT);
    CREATE LOCAL TEMPORARY COLUMN TABLE "#PREDICT" AS (SELECT * FROM :PREDICT);
END;


-- call SAP-RPT-1.6 using the SYS.AI_TABULAR_PREDICTION ;
DO BEGIN
    DECLARE PREDICTION TABLE(ID NVARCHAR(5000), COLUMN_NAME NVARCHAR(5000), PREDICTED_VALUE NVARCHAR(5000), CONFIDENCE DOUBLE);
 
    /*** Select a stratified random sample for ~2039 rows, of which ~39 are fraudulent flagged transaction, as context to the SAP-RPT-1.6 prediction call *******/
    CONTEXT = SELECT * FROM "#CONTEXT" ;
    
    /*** Select rows where to predict Fraud, which we also prepare as a stratified sample of ~104rows, which 8 are fraudulent in the test data *******************/
    PREDICT = SELECT * FROM "#PREDICT";
 
    
    /*** Predict with SAP-RPT-1.6 using the SYS.AI_TABULAR_PREDICTION Procedure in SAP HANA CLoud ****************************************************************/
    CALL SYS.AI_TABULAR_PREDICTION (
        REMOTE_SOURCE_SCHEMA_NAME => NULL,
        REMOTE_SOURCE_NAME => 'DA262_AICORE_RPT16',
        CONTEXT_TABLE => :CONTEXT,
        PREDICT_TABLE => :PREDICT,
        ID_COLUMN_NAME  => 'TRANSACTION_ID', 
        CONFIGURATION => '{"target_columns": [ {"name": "FRAUD", "task_type": "classification"}]}',
        PREDICT_RESULTS => :PREDICTION
    );
    
    SELECT * FROM :PREDICTION;
    CREATE LOCAL TEMPORARY COLUMN TABLE "#PREDICTION_RESULT" AS (SELECT * FROM :PREDICTION);
END;


-- Evaluate Accuracy;
DO BEGIN
    /*** Compare actuals with predicted one-by-one in a query ******************************************************************************************************/
    lt_PREDICT_IN = SELECT  TO_FIXEDCHAR(ID, 8) AS "ID", TO_INT(PREDICTED_VALUE)  AS CLASS, CONFIDENCE FROM #PREDICTION_RESULT;
    lt_ACTUALS_IN = SELECT  TO_FIXEDCHAR(A.TRANSACTION_ID, 8) AS "ID", TO_INT(FRAUD) AS CLASS FROM #PREDICTION_RESULT AS P, DA262_SHARED.TRANSACTIONS_FRAUD AS A WHERE P.ID=A.TRANSACTION_ID;
    
    SELECT A.ID, A.CLASS AS ACTUAL_CLASS, P.CLASS AS PREDICTED_CLASS, CONFIDENCE 
           FROM :lt_PREDICT_IN AS P, :lt_ACTUALS_IN AS A WHERE A.ID=P.ID;
    

    /*** Calculate binary classification accuracy metrics, and the confusion matrix using a custom SQL procedure ****************************************************/
    -- What is the F1_SCORE for fraudulent transactions?;
    CALL DA262_SHARED.CLASSIFICATION_ACCURACY(:lt_ACTUALS_IN, :lt_PREDICT_IN,  lt_cm, lt_cm_stats, lt_stats );
    select * from :lt_cm;
    select * from :lt_stats ORDER BY STAT_NAME;
END;





 

-- Step 4 - optional, prediction both, classification (Fraud) and regression (Amount) in one call;
DO BEGIN
    DECLARE PREDICTION TABLE(ID NVARCHAR(5000), COLUMN_NAME NVARCHAR(5000), PREDICTED_VALUE NVARCHAR(5000), CONFIDENCE DOUBLE);
 
       /*** Select a stratified random sample for ~2039 rows, of which ~39 are fraudulent flagged transaction, as context to the SAP-RPT-1.6 prediction call *******/
    CONTEXT = SELECT TRANSACTION_ID, ORIGIN, CLASS, AMOUNT, OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST, FRAUD 
    		  FROM DA262_SHARED.TRANSACTIONS_FRAUD TABLESAMPLE BERNOULLI (1.0) WHERE FRAUD = 0 AND TRANSACTION_ID < 200000  
    		  UNION 
    		  SELECT TRANSACTION_ID, ORIGIN, CLASS, AMOUNT, OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST, FRAUD 
    		  FROM DA262_SHARED.TRANSACTIONS_FRAUD TABLESAMPLE BERNOULLI (1.0) WHERE FRAUD = 1 AND TRANSACTION_ID < 200000 ;
    
    /*** Select rows where to predict Fraud, which we also prepare as a stratified sample of ~104rows, which 8 are fraudulent in the test data *******************/
    PREDICT = SELECT TRANSACTION_ID, ORIGIN, CLASS,  OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST 
    		  FROM DA262_SHARED.TRANSACTIONS_FRAUD TABLESAMPLE BERNOULLI (0.03) WHERE FRAUD = 0  AND TRANSACTION_ID > 200000 
    		  UNION 
              SELECT TRANSACTION_ID, ORIGIN, CLASS,  OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST 
    		  FROM DA262_SHARED.TRANSACTIONS_FRAUD TABLESAMPLE BERNOULLI (0.2) WHERE FRAUD = 1  AND TRANSACTION_ID > 200000;

 
    CALL SYS.AI_TABULAR_PREDICTION /*FOUNDATION_MODEL_PREDICT_DEV*/(
        REMOTE_SOURCE_SCHEMA_NAME => NULL,
        REMOTE_SOURCE_NAME => 'DA262_AICORE_RPT16',
        CONTEXT_TABLE => :CONTEXT,
        PREDICT_TABLE => :PREDICT,
        ID_COLUMN_NAME /* INDEX_COLUMN_NAME */ => 'TRANSACTION_ID', 
        /*PREDICT_SCHEMA => '{"FRAUD": "classification"}', */
        CONFIGURATION => '{"target_columns": [ {"name": "FRAUD", "task_type": "classification"}, 
                                               {"name": "AMOUNT", "task_type": "regression"}]}',
        PREDICT_RESULTS => :PREDICTION
    );
    SELECT * FROM :PREDICTION;
END;




