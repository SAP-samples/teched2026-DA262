
/** Predict with RPT-1 from SAP HANA Cloud - Feature available with SAP HANA Cloud 2026 Q2, June **************************************************/
-- doc, see https://github.wdf.sap.corp/hana-multi-model/vector-tech-documentation/blob/main/AI_TABULAR_PREDICTION.md */
- GX = Guided Experience, reference / SAP HANA Cloud Basic Trial
--https://community.sap.com/t5/technology-blog-posts-by-sap/hands-on-tutorial-leverage-automl-in-sap-hana-cloud-with-the-predictive/ba-p/13556400
--https://raw.githubusercontent.com/SAP-samples/hana-ml-samples/refs/heads/main/Python-API/usecase-examples/fraud-detection/BB_data.csv
--https://github.com/SAP-samples/hana-ml-samples/tree/main/Python-API/usecase-examples/fraud-detection
--tutorial dan for setup;


--checks by user;
SELECT * FROM REMOTE_SOURCES;



SELECT TRANSACTION_ID, ORIGIN, CLASS, AMOUNT, OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST, FRAUD
FROM DA262_SHARED.TRANSACTIONS_FRAUD ORDER BY TRANSACTION_ID;


DO BEGIN
    DECLARE PREDICTION TABLE(ID NVARCHAR(5000), COLUMN_NAME NVARCHAR(5000), PREDICTED_VALUE NVARCHAR(5000), CONFIDENCE DOUBLE);
 
    CONTEXT = SELECT TRANSACTION_ID, ORIGIN, CLASS, AMOUNT, OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST, FRAUD 
    		  FROM DA262_SHARED.TRANSACTIONS_FRAUD WHERE TRANSACTION_ID < 1000 ;
    PREDICT = SELECT TRANSACTION_ID, ORIGIN, CLASS, AMOUNT, OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST
    		 FROM DA262_SHARED.TRANSACTIONS_FRAUD WHERE TRANSACTION_ID between 1000 AND 1050;
 
    CALL SYS.AI_TABULAR_PREDICTION /*FOUNDATION_MODEL_PREDICT_DEV*/(
        REMOTE_SOURCE_SCHEMA_NAME => NULL,
        REMOTE_SOURCE_NAME => 'DA262_AICORE_RPT16',
        CONTEXT_TABLE => :CONTEXT,
        PREDICT_TABLE => :PREDICT,
        ID_COLUMN_NAME /* INDEX_COLUMN_NAME */ => 'TRANSACTION_ID', 
        /*PREDICT_SCHEMA => '{"FRAUD": "classification"}', */
        CONFIGURATION => '{"target_columns": [ {"name": "FRAUD", "task_type": "classification"}]}',
        PREDICT_RESULTS => :PREDICTION
    );
    SELECT * FROM :PREDICTION;
    --CREATE COLUMN TABLE TRANSACTIONS_PREDICTED AS (SELECT * FROM :PREDICTION);
    CALL DA262_SHARED.CLASSIFICATION_ACCURACY( lt_class_stats );
    select * from :lt_class_stats;
END;

CREATE COLUMN TABLE DA262_001.TRANSACTIONS_ACTUALS AS (
SELECT TRANSACTION_ID, FRAUD
    		 FROM DA262_SHARED.TRANSACTIONS_FRAUD WHERE TRANSACTION_ID between 1000 AND 1050);


DO BEGIN
    DECLARE PREDICTION TABLE(ID NVARCHAR(5000), COLUMN_NAME NVARCHAR(5000), PREDICTED_VALUE NVARCHAR(5000), CONFIDENCE DOUBLE);
 
    CONTEXT = SELECT TRANSACTION_ID, ORIGIN, CLASS, AMOUNT, OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST, FRAUD 
    		  FROM DA262_SHARED.TRANSACTIONS_FRAUD WHERE TRANSACTION_ID < 1000 ;
    PREDICT = SELECT TRANSACTION_ID, ORIGIN, CLASS, OLD_BALANCE_ORIGIN, NEW_BALANCE_ORIGIN, DESTINATION, OLD_BALANCE_DEST, NEW_BALANCE_DEST
    		 FROM DA262_SHARED.TRANSACTIONS_FRAUD WHERE TRANSACTION_ID between 1000 AND 1050;
 
    CALL SYS.AI_TABULAR_PREDICTION /*FOUNDATION_MODEL_PREDICT_DEV*/(
        REMOTE_SOURCE_SCHEMA_NAME => NULL,
        REMOTE_SOURCE_NAME => 'DA262_AICORE_RPT16',
        CONTEXT_TABLE => :CONTEXT,
        PREDICT_TABLE => :PREDICT,
        ID_COLUMN_NAME /* INDEX_COLUMN_NAME */ => 'TRANSACTION_ID', 
        /*PREDICT_SCHEMA => '{"FRAUD": "classification"}', */
        CONFIGURATION => '{"target_columns": [ {"name": "FRAUD", "task_type": "classification"}, 
                                               {"name": "AMOUNT", "task_type": "regression"}]}',
        PREDICT_RESULTS => :PREDICTION
    );
    SELECT * FROM :PREDICTION;
END;


/***********************/
/** Some prep-steps would be required: Define RPT-1 Remote Source **************/
--CREATE PSE BTP_EMBEDDING_PSE;
--ALTER PSE BTP_EMBEDDING_PSE SET OWN CERTIFICATE '
-----BEGIN RSA PRIVATE KEY-----123...-----END RSA PRIVATE KEY-----
-----BEGIN CERTIFICATE-----ABC...-----END CERTIFICATE-----
--';

-- Create remote source for RPT-1
/*CREATE REMOTE SOURCE DA262_AICORE_RPT16 ADAPTER "sapgenaihub" CONFIGURATION
    'aiApiUrl=https://api.ai.internalprod.eu-central-1.aws.ml.hana.ondemand.com;
     authUrl=https://ai-core-wklw5w1s.authentication.cert.sap.hana.ondemand.com;
     resourceGroup=default;
     deploymentId=XYZ;
     clientId=1a2b###'
WITH CREDENTIAL TYPE 'X509' PSE BTP_EMBEDDING_PSE;*/

--privileges
--GRANT EXECUTE ON REMOTE SOURCE DA262_AICORE_RPT16 TO <USER>;
--GRANT EXECUTE ON SYS.AI_TABULAR_PREDICTION TO <USER>;

