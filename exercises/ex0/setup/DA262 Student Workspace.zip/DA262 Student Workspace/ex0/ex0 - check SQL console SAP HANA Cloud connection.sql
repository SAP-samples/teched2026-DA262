
/*** Test SAP HANA Cloud connection and SQL console - Check for remote sources defined in the instance ***/
SELECT * FROM REMOTE_SOURCES;